AKTIV GROTESK, DESKTOP FONTS
LA.IO brand system  ·  assets.la.io

Nine weights, TrueType. For Adobe apps, Microsoft Office, DaVinci Resolve,
After Effects and Premiere. Web work does not use these files: see
https://assets.la.io/ai for the web and artifact instructions.

INSTALL, MAC
1. Unzip this folder.
2. Select every .ttf file.
3. Double-click, then click Install Font. Or drag them into ~/Library/Fonts.
4. Quit and reopen the app you are working in.

INSTALL, WINDOWS
1. Unzip this folder.
2. Select every .ttf file.
3. Right-click, then Install for all users.
4. Quit and reopen the app you are working in.

USING IT
+ Headlines: Light 300 or Bold 700. Never a middle weight as a headline.
+ Body: Regular 400.
+ Family name is "Aktiv Grotesk", title case.
+ JetBrains Mono handles eyebrows, labels, tags and metadata. All caps,
  letter spacing 0.08 to 0.12em, always a brand accent color.

POWERPOINT, WORD, GOOGLE
The font does not travel in an Office file and Google Workspace cannot use it
at all. Anything leaving the team as .pptx or .docx gets Roboto, or Arial if
Roboto is not installed. Anything in Google Slides or Docs gets Roboto.
A PDF carries the font, so export to PDF when the type has to hold.

LICENSE
The license covers the LA.IO team. LicenceAgreement.pdf is included.
Do not redistribute these files outside LA.IO.
